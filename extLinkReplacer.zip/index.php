<?php // Silence is golden

