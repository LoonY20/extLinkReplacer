<?php
define('ROOT_CORE', __DIR__);
define('DS', DIRECTORY_SEPARATOR);
define('WP_ROOT', $_SERVER['DOCUMENT_ROOT']);